﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordsBook.Model
{
    class Account : INotifyPropertyChanged
    {
        private string password;

        public Account (string password)
        {
            this.password = password;
        }
        
        public string Password { get { return password; } set { password = value; OnPropertyChanged("Password"); } }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
