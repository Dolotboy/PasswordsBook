﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PasswordsBook.Command;
using PasswordsBook.Model;
using System.Windows;
using System.IO;
using MY_CSHARP_LIBRARY; // Pour l'encryption du mot de passe

namespace PasswordsBook.ViewModel
{
    class InscriptionViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private BaseViewModel viewModelActif;
        private MainViewModel viewModelParent;

        private Account anAccount;
        private string dataFolder = @"C:\\PasswordBook\\Data";
        private string passFolder;

        private string confirmationPassword;

        private BaseCommand inscriptionCommand;
        private BaseCommand backCommand;

        private StringEncryptor stringEncryptor = new StringEncryptor(); // Pour l'encryption de mot de passe 
        private StringCorruptor stringCorruptor = new StringCorruptor(); // Pour corrompre le string


        public InscriptionViewModel(MainViewModel viewModelParent)
        {
            anAccount = new Account("");
            this.viewModelParent = viewModelParent;
            ViewModelActif = this;
            inscriptionCommand = new BaseCommand(ClickOnInscription, CanClickOnInscription);
            backCommand = new BaseCommand(ClickOnBack, obj => true);
        }

        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }
        public Account AnAccount { get { return anAccount; } set { anAccount = value; OnPropertyChanged("AnAccount"); } }

        public string ConfirmationPassword { get { return confirmationPassword; } set { confirmationPassword = value; OnPropertyChanged("ConfirmationPassword"); } }
        public BaseCommand InscriptionCommand { get { return inscriptionCommand; } private set { inscriptionCommand = value; } }
        public BaseCommand BackCommand { get { return backCommand; } private set { backCommand = value; } }

        private void ClickOnInscription(object nothing)
        {
            if (anAccount.Password != confirmationPassword)
            {
                MessageBox.Show("Les deux mots de passes ne concorde pas !", "Avertissement");
            }
            else
            {
                try
                {
                    if (!Directory.Exists(dataFolder))
                    {
                        Directory.CreateDirectory(dataFolder);
                    }
                    
                    passFolder = stringCorruptor.CorruptString(stringEncryptor.EncryptString(anAccount.Password)); // Encryption et Corruption du mot de passe ERREUR À CETTE LIGNE, LORS DU DÉBOGUAGE TOUT EST CORRECTE, MAIS SI JE DEBUG PAS SA BUG
                    var accountFolder = new DirectoryInfo(dataFolder);
                    bool canCreate = true; // Dans le cas ou il n'y aurais pas déjà de compte créé, car le foreach se skip dans ce cas

                    foreach (DirectoryInfo directories in accountFolder.GetDirectories()) // Vérifier si le mot de passe existe déjà, car sa causerais des problèmes lors de la connexion
                    {
                        string dirName = stringCorruptor.UnCorruptString(directories.Name);
                        dirName = stringEncryptor.EncryptString(dirName);
                        if (String.Equals(anAccount.Password, dirName))
                        {
                            canCreate = false;
                            break;
                        }
                    }
                    if (canCreate)
                    {
                        string pathString = Path.Combine(dataFolder, passFolder); // Création du chemin vers le dossier du nom du mot de passe encrypté
                        Directory.CreateDirectory(pathString); // Création du dossier du nom du mot de passe encrypté
                        MessageBox.Show("Le compte a été créé avec succès", "Avertissement");
                    }
                    else
                    {
                        MessageBox.Show("Votre mot de passe ne nous convient pas !", "Avertissement");
                        ClickOnBack(nothing);
                    }
                }
                catch
                {
                    MessageBox.Show("Il y a eu une erreur lors de la création de votre compte, veuillez réessayer !", "Avertissement");
                }
                ClickOnBack(nothing);
            }
        }

        private bool CanClickOnInscription(object nothing)
        {
            bool can = true;
            if (String.IsNullOrEmpty(anAccount.Password) || String.IsNullOrEmpty(confirmationPassword))
            {
                can = false;
            }
            return can;
        }

        public void ClickOnBack(object nothing)
        {
            viewModelParent.ViewModelActif = new MenuViewModel(viewModelParent);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}