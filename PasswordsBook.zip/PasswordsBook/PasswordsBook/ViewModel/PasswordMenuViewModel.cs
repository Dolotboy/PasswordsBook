﻿using PasswordsBook.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordsBook.ViewModel
{
    class PasswordMenuViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private BaseViewModel viewModelActif;
        private MainViewModel viewModelParent;
        private BaseCommand connectCommand;
        private BaseCommand inscriptionCommand;
        private BaseCommand logoutCommand;
        public PasswordMenuViewModel(MainViewModel viewModelParent)
        {
            this.viewModelParent = viewModelParent;
            ViewModelActif = this;
            connectCommand = new BaseCommand(ClickOnConnect, obj => true);
            inscriptionCommand = new BaseCommand(ClickOnInscription, obj => true);
        }

        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }
        public BaseCommand ConnectCommand { get { return connectCommand; } private set { connectCommand = value; } }
        public BaseCommand InscriptionCommand { get { return inscriptionCommand; } private set { inscriptionCommand = value; } }
        public BaseCommand LogoutCommand { get { return logoutCommand; } private set { logoutCommand = value; } }


        // Ce que la commande envoie viewModelParent.ViewModelActif = new TransitionViewModel(viewModelParent);

        public void ClickOnConnect(object nothing)
        {
            viewModelParent.ViewModelActif = new ConnectionViewModel(viewModelParent);
        }

        public void ClickOnInscription(object nothing)
        {
            viewModelParent.ViewModelActif = new InscriptionViewModel(viewModelParent);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
