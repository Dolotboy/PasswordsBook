﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordsBook.ViewModel
{
    class MainViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private BaseViewModel viewModelActif;

        public MainViewModel()
        {
            ViewModelActif = new MenuViewModel(this); // Ici on décide sur qu'elle fenêtre on veux commencer
        }

        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
