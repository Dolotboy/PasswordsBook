﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PasswordsBook.Command;

namespace PasswordsBook.ViewModel
{
    class BaseViewModel
    {
    }
}

/*
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PasswordsBook.Command;

namespace PasswordsBook.ViewModel
{
    class ConnectionViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private BaseViewModel viewModelActif;
        private MainViewModel viewModelParent;

        public ConnectionViewModel(MainViewModel viewModelParent)
        {
            this.viewModelParent = viewModelParent;
            ViewModelActif = this;
        }

        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
*/
