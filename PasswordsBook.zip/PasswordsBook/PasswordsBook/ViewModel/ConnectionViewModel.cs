﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PasswordsBook.Command;
using PasswordsBook.Model;
using MY_CSHARP_LIBRARY;
using System.Windows;

namespace PasswordsBook.ViewModel
{
    class ConnectionViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private BaseViewModel viewModelActif;
        private MainViewModel viewModelParent;

        private Account anAccount;
        private string dataFolder = @"C:\\PasswordBook\\Data";
        private StringEncryptor stringEncryptor = new StringEncryptor();
        private StringCorruptor stringCorruptor = new StringCorruptor();


        private BaseCommand connectionCommand;
        private BaseCommand backCommand;


        public ConnectionViewModel(MainViewModel viewModelParent)
        {
            anAccount = new Account("");
            this.viewModelParent = viewModelParent;
            ViewModelActif = this;
            connectionCommand = new BaseCommand( ClickOnConnection, CanClickOnConnection );
            backCommand = new BaseCommand( ClickOnBack, obj => true );
        }

        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }
        public Account AnAccount { get { return anAccount; } set { anAccount = value; OnPropertyChanged("AnAccount"); } }
        public BaseCommand ConnectionCommand { get { return connectionCommand; } private set { connectionCommand = value; } }
        public BaseCommand BackCommand { get { return backCommand; } private set { backCommand = value; } }

        private void ClickOnConnection(object nothing)
        {
            var accountFolder = new DirectoryInfo(dataFolder);
            bool badPassword = true;
            foreach(DirectoryInfo directories in accountFolder.GetDirectories())
            {
                string password = stringCorruptor.UnCorruptString(directories.Name);
                password = stringEncryptor.EncryptString(password); // FullName serait le chemin du dossier
                if (String.Equals(AnAccount.Password, password))
                {
                    MessageBox.Show("Connexion");
                    viewModelParent.ViewModelActif = new PasswordMenuViewModel(viewModelParent);
                    badPassword = false;
                    break;
                }
            }
            if (badPassword)
            {
                MessageBox.Show("Mot de passe éroné !", "Avertissement");
            }
        }

        private bool CanClickOnConnection(object nothing)
        {
            bool can = true;
            if (String.IsNullOrEmpty(anAccount.Password))
            {
                can = false;
            }
            return can;
        }

        public void ClickOnBack(object nothing)
        {
            viewModelParent.ViewModelActif = new MenuViewModel(viewModelParent);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
